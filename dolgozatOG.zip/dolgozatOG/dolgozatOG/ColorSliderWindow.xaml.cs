﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace dolgozatOG
{
    /// <summary>
    /// Interaction logic for ColorSliderWindow.xaml
    /// </summary>
    public partial class ColorSliderWindow : Window
    {
        public ColorSliderWindow()
        {
            InitializeComponent();
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte redsl = (byte)rSlider.Value;
            byte greensl = (byte)gSlider.Value;
            byte bluesl = (byte)bSlider.Value;

            panelColorChanged(redsl, greensl, bluesl);
        }

        private void panelColorChanged(byte redsl, byte greensl, byte bluesl)
        {
            MainGrid.Background = new SolidColorBrush(Color.FromRgb(redsl, greensl, bluesl));

            byte redsl_valami = (byte)(255 - redsl);
            byte greensl_valami = (byte)(255 - greensl);
            byte bluesl_valami = (byte)(255 - bluesl);
            caption.Foreground = new SolidColorBrush(Color.FromRgb(redsl_valami, greensl_valami, bluesl_valami));
        }
    }
}
